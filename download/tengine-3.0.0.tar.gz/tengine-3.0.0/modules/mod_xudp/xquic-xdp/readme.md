## config
```
make config root=/path/to/libxudp
```

## build
```
make
```

## how to use

see test.c. this from libxudp/tools/xudp_echo_server.c

see the commit b6170f0557db95a2ef74346515759d35f4cc70de to know how to
use this xquic xdp.

